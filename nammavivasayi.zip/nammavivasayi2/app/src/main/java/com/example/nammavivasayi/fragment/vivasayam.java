package com.example.nammavivasayi.fragment;

import android.content.Intent;
import android.os.Bundle;


import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.Toast;

import com.example.nammavivasayi.Agristudies;
import com.example.nammavivasayi.Bookmyslot;
import com.example.nammavivasayi.Dwaterlevel;
import com.example.nammavivasayi.Feedback;
import com.example.nammavivasayi.Fertilizer;
import com.example.nammavivasayi.Flowermarket;
import com.example.nammavivasayi.Fruits;
import com.example.nammavivasayi.Livestock;
import com.example.nammavivasayi.Localmarket;
import com.example.nammavivasayi.Machine;
import com.example.nammavivasayi.Marketprice;
import com.example.nammavivasayi.R;
import com.example.nammavivasayi.Seed;
import com.example.nammavivasayi.Vegmarket;
import com.example.nammavivasayi.Weather;
import com.example.nammavivasayi.farmplan;

public class vivasayam extends Fragment {

        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_vivasayam, container, false);
    }


    }
