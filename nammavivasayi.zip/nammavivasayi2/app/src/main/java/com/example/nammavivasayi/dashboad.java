package com.example.nammavivasayi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.Toast;

import com.example.nammavivasayi.fragment.vivasayam;

public class dashboad extends AppCompatActivity {
     GridLayout mygrid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboad);
        mygrid=findViewById(R.id.mygrid);
        setSingleEvent(mygrid);

    }

    private void setSingleEvent(GridLayout mygrid){
        for (int i=0; i<mygrid.getChildCount();i++){
            CardView CardView = (CardView) mygrid.getChildAt(i);
            final int finalI = i;
            CardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (finalI == 0) {
                        Intent intent = new Intent(dashboad.this, farming.class);
                        startActivity(intent);

                    } else if (finalI == 1) {
                        Intent intent = new Intent(dashboad.this, Livestock.class);
                        startActivity(intent);

                    } else if (finalI == 2) {
                        Intent intent = new Intent(dashboad.this, Fertilizer.class);
                        startActivity(intent);

                    } else if (finalI == 3) {
                        Intent intent = new Intent(dashboad.this, Dwaterlevel.class);
                        startActivity(intent);
                    } else if (finalI == 4) {
                        Intent intent = new Intent(dashboad.this, Weather.class);
                        startActivity(intent);
                    } else if (finalI == 5) {
                        Intent intent = new Intent(dashboad.this, Seed.class);
                        startActivity(intent);
                    } else if (finalI == 6) {
                        Intent intent = new Intent(dashboad.this, Localmarket.class);
                        startActivity(intent);
                    } else if (finalI == 7) {
                        Intent intent = new Intent(dashboad.this, Vegmarket.class);
                        startActivity(intent);
                    } else if (finalI == 8) {
                        Intent intent = new Intent(dashboad.this, Flowermarket.class);
                        startActivity(intent);
                    } else if (finalI == 9) {
                        Intent intent = new Intent(dashboad.this, Machine.class);
                        startActivity(intent);
                    } else if (finalI == 10) {
                        Intent intent = new Intent(dashboad.this, farmplan.class);
                        startActivity(intent);
                    } else if (finalI == 11) {
                        Intent intent = new Intent(dashboad.this, Marketprice.class);
                        startActivity(intent);
                    }else if (finalI == 12) {
                        Intent intent = new Intent(dashboad.this, Agristudies.class);
                        startActivity(intent);
                    }else if (finalI == 13) {
                        Intent intent = new Intent(dashboad.this, Feedback.class);
                        startActivity(intent);
                    }else if (finalI == 14) {
                        Intent intent = new Intent(dashboad.this, Bookmyslot.class);
                        startActivity(intent);
                    }else if (finalI == 15) {
                        Intent intent = new Intent(dashboad.this, Fruits.class);
                        startActivity(intent);


                    } else {
                        Toast.makeText(dashboad.this, "no items", Toast.LENGTH_SHORT).show();
                    }


                }





                });
        }
    }
}